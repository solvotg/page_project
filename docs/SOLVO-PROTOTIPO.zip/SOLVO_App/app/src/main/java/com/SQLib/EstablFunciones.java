package com.SQLib;

public class EstablFunciones {

}
