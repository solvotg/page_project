package com.dynamodb;

public class Utils {
    public static String mybucket = "solvo-conductor";
}
