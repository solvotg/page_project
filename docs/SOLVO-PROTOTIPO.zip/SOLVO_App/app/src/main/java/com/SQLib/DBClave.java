package com.SQLib;

public class DBClave {

    public static final int SYNC_STATUS_OK = 0;
    public static final int SYNC_STATUS_FAILED = 1;

    //public static final String SERVER_URL = "http://10.0.2.2/syncdemo/syncdemo.php";
    public static final String SERVER_URL = "http://54.145.165.9/test.php";
    public static final String DATABASE_NAME = "";
    public static final String TABLE_NAME = "";



}
